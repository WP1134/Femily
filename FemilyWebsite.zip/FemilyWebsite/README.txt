Mở index.html để bắt đầu website Femily.
Không cần cài đặt thêm, chạy trực tiếp trong trình duyệt.